# Healthcare Appointment Booking System

A full-stack learning project for discovering doctors and managing healthcare appointments.

## Features planned
- Browse doctors and specialties
- Request appointments for a date and time
- View and cancel appointments
- Admin tools for managing doctors and schedules

## Stack
- Frontend: React + Vite
- Backend: Node.js + Express
- Database: PostgreSQL

## Status
Starter scaffold. Test features before treating them as complete. Portfolio demo only; do not enter real patient data.

## Local setup
Requirements: Node.js 20+ and PostgreSQL 14+.

1. Create a PostgreSQL database named `healthcare_booking`.
2. Run `backend/schema.sql` against that database.
3. In `backend`, copy `.env.example` to `.env` and set your local database URL.
4. Run `npm install` and `npm run dev` in `backend`.
5. In another terminal, run `npm install` and `npm run dev` in `frontend`.
6. Open the local URL Vite prints (usually `http://localhost:5173`).

## Security
This starter has no real user authentication. Before production, implement verified authentication, authorization, rate limiting, stronger validation, migrations, tests, and secure deployment. Never commit secrets or real patient data.
