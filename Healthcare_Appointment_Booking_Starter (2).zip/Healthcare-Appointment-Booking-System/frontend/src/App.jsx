import { useEffect, useState } from 'react';
const API = import.meta.env.VITE_API_URL || 'http://localhost:4000';

export default function App() {
  const [doctors, setDoctors] = useState([]);
  const [message, setMessage] = useState('');
  const [form, setForm] = useState({ patientName:'', patientEmail:'', doctorId:'', appointmentDate:'', appointmentTime:'10:00' });
  useEffect(() => {
    fetch(`${API}/api/doctors`).then(r => { if (!r.ok) throw Error(); return r.json(); })
      .then(setDoctors).catch(() => setMessage('Backend/database not connected yet. Follow the README setup steps.'));
  }, []);
  const update = e => setForm({ ...form, [e.target.name]: e.target.value });
  async function book(e) {
    e.preventDefault(); setMessage('');
    try {
      const r = await fetch(`${API}/api/appointments`, { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(form) });
      const data = await r.json();
      if (!r.ok) throw Error(data.error || 'Booking failed');
      setMessage(`Appointment request created. Reference #${data.id}`);
      setForm({ ...form, patientName:'', patientEmail:'' });
    } catch (err) { setMessage(err.message || 'Unable to book. Check backend and database.'); }
  }
  return <main className="page">
    <nav className="nav"><a className="brand" href="#"><span className="brand-mark">+</span> CarePoint</a><span className="nav-note">Healthcare Appointment Booking</span></nav>
    <section className="hero"><div className="hero-copy"><p className="eyebrow">CARE THAT FITS YOUR SCHEDULE</p><h1>Your health.<br/><span>Your time.</span></h1><p className="intro">Find a specialist and request an appointment in just a few simple steps.</p><div className="trust"><span>✓</span> Simple booking <span>✓</span> Clear information <span>✓</span> Patient-focused</div></div>
    <div className="hero-art" aria-hidden="true"><div className="sun"></div><div className="cross">+</div><div className="art-card"><div className="avatar">✚</div><div><b>Care, made easier</b><small>Appointments in one place</small></div><span className="check">✓</span></div><div className="art-circle"></div></div></section>
    <section className="content"><div className="section-heading"><div><p className="eyebrow">GET STARTED</p><h2>Book an appointment</h2></div><p>Complete the form to request your visit.</p></div>
    <form className="booking-card" onSubmit={book}><div className="form-grid">
      <label>Full name<input name="patientName" value={form.patientName} onChange={update} placeholder="Enter your name" required maxLength="120"/></label>
      <label>Email address<input name="patientEmail" type="email" value={form.patientEmail} onChange={update} placeholder="you@example.com" required maxLength="254"/></label>
      <label className="wide">Choose a doctor<select name="doctorId" value={form.doctorId} onChange={update} required><option value="">Select a specialist</option>{doctors.map(d=><option key={d.id} value={d.id}>{d.name} — {d.specialty} · ₹{d.consultation_fee}</option>)}</select></label>
      <label>Appointment date<input type="date" name="appointmentDate" value={form.appointmentDate} onChange={update} min={new Date().toISOString().slice(0,10)} required/></label>
      <label>Preferred time<select name="appointmentTime" value={form.appointmentTime} onChange={update} required>{['09:00','10:00','11:00','12:00','14:00','15:00','16:00'].map(t=><option key={t} value={t}>{t}</option>)}</select></label>
    </div><button className="submit" type="submit">Request appointment <span>→</span></button>{message&&<p className="message" role="status">{message}</p>}<p className="disclaimer">Demo project only. Do not enter real or sensitive medical information.</p></form></section>
    <footer>CarePoint <span>Portfolio demonstration · Not a real healthcare service</span></footer>
  </main>;
}
